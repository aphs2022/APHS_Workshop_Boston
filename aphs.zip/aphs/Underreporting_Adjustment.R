#install.packages('tidyverse')
#install.packages('devtools')
#install.packages("usmap")
#install.packages("INLA",repos=c(getOption("repos"),INLA="https://urldefense.com/v3/__https://inla.r-inla-download.org/R/stable__;!!MXfaZl3l!Z7KjtXXurVMVM1Zc8K3ETZJl6SBYJfoy3CIqxYnoHTG0Jm-GDZ8Gzcg2cvWoDA421cnVPyUPjOjtNqkjhdutG-5Gjfb2sZY$  "), dep=TRUE)

library(sf)
library(raster)
library(dplyr)
library(spData)
#Note that you will have to install spDataLarge after installing spData
#install.packages('spDataLarge', repos='https://urldefense.com/v3/__https://nowosad.github.io/drat/__;!!MXfaZl3l!Z7KjtXXurVMVM1Zc8K3ETZJl6SBYJfoy3CIqxYnoHTG0Jm-GDZ8Gzcg2cvWoDA421cnVPyUPjOjtNqkjhdutG-5GsiwYReU$  ', type='source')
library(spDataLarge)
library(tidyverse)
library(usmap)
library(ggplot2)
library(INLA)
library(rgdal)
library(sp)
library(tableone)

```

## Research Question and Data file
#load the alcohol fatality data
alc.data = read.csv("alc_data.csv", header = T)

head(alc.data)
Mat1 <- read.table("WeightNC.txt")
WeightNC <- as.matrix(Mat1)

alc.data$Urban = as.numeric (alc.data$RuralProp < 0.50) 
alc.data$Rural = as.numeric (alc.data$RuralProp >= 0.50)

alc.data$EC = sum(alc.data$fatalcounts)/sum(alc.data$population2019)*alc.data$population2019
alc.data$ID <- 1:100
tab1 <- CreateTableOne (vars = c ("ID", "AgeBelow18", "Female_Prop", "AAprop",
                                  "Unemployment", "SomeCollege", "RuralProp", "EC", "Rural", "Urban"),
                        data = alc.data)


#not adjusting for underreporting
prior.fixed1 <- list(mean.intercept = 0, prec.intercept = 0.0001,
                     mean = c(0, 0, 0, 0,0,0), prec = c(0.0001, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001))
prec.prior2 <- list(prec = list(param = c(0.001, 0.001)))

NC.Mat <- as.matrix(WeightNC)
formula1a <- fatalcounts ~ AgeBelow18 + Female_Prop + AAprop + Unemployment + HighSchool + RuralProp + f(ID, model = "bym", graph = NC.Mat)

dat2.inla <- inla(formula1a, family='nbinomial', E=EC,
                  data=alc.data,
                  control.family=list(link='log'),
                  control.fixed = prior.fixed1,
                  control.predictor=list(link=1, compute=TRUE),
                  control.compute=list(dic=TRUE, cpo=TRUE, waic=TRUE))

summary(dat2.inla)

## Adjusting for same underreprting rates

dat3.inla <- inla(formula1a, family='nbinomial', E=EC1,
                  data=alc.data,
                  control.family=list(link='log'),
                  control.fixed = prior.fixed1,
                  control.predictor=list(link=1, compute=TRUE),
                  control.compute=list(dic=TRUE, cpo=TRUE, waic=TRUE))

summary(dat3.inla)




#adjusting for rural/urban different underreporting rates
prior.fixed <- list(mean.intercept = 0, prec.intercept = 0.0001,
                    mean = c(-1.14, -1.14, 0, 0, 0, 0,0), prec = c(0.01, 0.01, 0.0001, 0.0001, 0.0001, 0.0001, 0.0001))
prec.prior <- list(prec = list(param = c(0.001, 0.001)))


formula1 <- fatalcounts ~ Urban + Rural + AgeBelow18 + Female_Prop + AAprop + Unemployment + HighSchool + RuralProp + f(ID, model = "bym", graph = NC.Mat)

dat.inla <- inla(formula1, family='nbinomial', E=EC,
                 data=alc.data,
                 control.family=list(link='log'),
                 control.fixed = prior.fixed,
                 control.predictor=list(link=1, compute=TRUE),
                 control.compute=list(dic=TRUE, cpo=TRUE, waic=TRUE))

summary(dat.inla)

